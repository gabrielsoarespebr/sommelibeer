const store = document.querySelector('.stores-list');

/*
for (var i = 0; i < stores().length; i++) {
    store.innerHTML += '<div class="store"><a href="' + stores()[i].href + '" class="store-link" target="_blank">' +
        '<img src="' + stores()[i].img + '" alt="Logotipo da loja" class="store-logo">' +
        '<span class="store-name">' + stores()[i].name + '</span><span class="store-price">R$' + stores()[i].price + '</span></a></div>'
}
*/