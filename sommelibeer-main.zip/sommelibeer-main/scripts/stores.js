export function stores() //Lista de lojas e seus respectivos preços
{
    let store0001 = { name: "Big Bompreço", price: 10.63, img: "images/stores/BigBompreco.png", href: "https://www.bompreco.com.br/cerveja-lager-heineken-600ml-0000078905498/p?idsku=2144&gclid=Cj0KCQjw166aBhDEARIsAMEyZh76UyiZanik9AvtgiLo4wjaUILGWnbsDpUnXKaiIqSV6croRh5vL2QaAiOiEALw_wcB" };

    let store0002 = { name: "Pão de Açúcar", price: 11.29, img: "images/stores/PaodeAcucar.png", href: "https://www.paodeacucar.com/produto/105770/cerveja-heineken-garrafa-600ml" };

    let store0003 = { name: "Americanas", price: 13.87, img: "images/stores/Americanas.png", href: "https://www.americanas.com.br/produto/5732485437?pfm_carac=heineken-600ml&pfm_index=2&pfm_page=search&pfm_pos=grid&pfm_type=search_page&offerId=6304ecc9adbc5f39b9a87a78" };

    let store0004 = { name: "Extra", price: 15.26, img: "images/stores/Extra.png", href: "https://www.extra.com.br/cerveja-heineken-600ml-pack-6-unidades-1508841442/p/1508841442?utm_medium=cpc&utm_source=GP_PLA&IdSku=1508841442&idLojista=12231&tipoLojista=3P&&utm_campaign=3P_ALLPRODUCTS_PMAX&gclid=Cj0KCQjw166aBhDEARIsAMEyZh5kxvvv8gTahXLantILJkliPSp-JGW7N1kzZR7-AiL3Ch79Lqt9YskaAnnEEALw_wcB&gclsrc=aw.ds" };

    let store0005 = { name: "Carrefour", price: 15.90, img: "images/stores/Carrefour.png", href: "https://www.carrefour.com.br/cerveja-heineken-600ml---pack-6-unidades-mp912776129/p" };

    let stores = [store0001, store0002, store0003, store0004, store0005];
    return stores;
}